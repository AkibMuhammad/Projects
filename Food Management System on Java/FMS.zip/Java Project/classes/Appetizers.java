package classes;
import java.lang.*;

public class Appetizers extends FoodItem
{
	private String size;
	
	public void setSize(String size)
	{
		this.size = size;
	}
	
	public String getSize()
	{
		return size;
	}
	public void showInfo()
	{
		System.out.println("Food ID: " +getFid());
		System.out.println("Food Name: " +getName());
		System.out.println("Quantity: " +getAvailabequantity());
		System.out.println("Price: " +getPrice());
		System.out.println("Size :" +getSize());
		System.out.println();
	}
}