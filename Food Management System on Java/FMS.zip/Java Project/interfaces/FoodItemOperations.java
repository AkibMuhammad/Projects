package interfaces;
import classes.*;
public interface CustomerOperations
{
	void insertFoodItem(FoodItem f) ;
	void removeFoodItem(FoodItem f) ;
	FoodItem getFoodItem(String fid) ;
	void showAllFoodItems() ;
}