package interfaces;
import java.lang.*;
import classes.FoodItem;

public interface IQuantity 
{
	void addQuantity(int amount) ;
	void sellQuantity(int amount) ;
}