import java.lang.*;
import classes.*;
import interfaces.*;
import fileio.*;
import java.util.*;

public class Start
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Bank b = new Bank();
		FileReadWriteDemo frwd = new FileReadWriteDemo();
		
		boolean choice = true;
		
		while(choice)
		{
			System.out.println("Choose from the Following Options: ");
			System.out.println("--------------------------------------");
			System.out.println("1. Employee Management");
			System.out.println("2. Restaurant Management");
			System.out.println("3. Restaurant FoodItem Management");
			System.out.println("4. FoodItem Quantity Add-Sell");
			System.out.println("5. Exit");
			System.out.println("--------------------------------------\n");
			
			System.out.print("You have choosed: ");
			int option = sc.nextInt();
			
			switch(option)
			{
				case 1:
				
					System.out.println("********************");
					System.out.println("Employee Management");
					System.out.println("What do you want to do?\n");
					System.out.println("--------------------------------------");
					System.out.println("1. Insert New Employee");
					System.out.println("2. Remove Existing Employee");
					System.out.println("3. Show All Employees");
					System.out.println("4. Search An Employee");
					System.out.println("5. Go Back");
					System.out.println("--------------------------------------\n");
					System.out.print("Enter your option: ");
					int input1 = sc.nextInt();
					
					switch(input1)
					{
						case 1:
							
							System.out.println("#####################");
							System.out.println("Insert New Employee");
							
							System.out.print("Enter Employee ID: ");
							String empId1 = sc.next();
							
							System.out.print("Enter Employee Name: ");
							String name1 = sc.next();
							
							System.out.print("Enter Employee Salary: ");
							double salary = sc.nextDouble();
							
							Employee e1 = new Employee();
							e1.setEmpId(empId1);
							e1.setName(name1);
							e1.setSalary(salary);
							
							b.insertEmployee(e1);
							
							System.out.println("#####################");
							break;
							
						case 2:
							System.out.println("#####################");
							System.out.println("Remove Existing Employee");
							
							System.out.print("Enter Employee ID: ");
							String empId2 = sc.next();
							
							Employee e2 = b.getEmployee(empId2);
							b.removeEmployee(e2);
							
							System.out.println("#####################");
							break;	
							

						case 3:
							
							System.out.println("#####################");
							System.out.println("Show All Employees");
							
							b.showAllEmployees();
							System.out.println("#####################");
							break;

						case 4:
								
                            System.out.println("#####################");
							System.out.println("Search An Employee");
							
							System.out.print("Enter Employee ID: ");
							String empId3 = sc.next();
							
							Employee e3 = b.getEmployee(empId3);
							
							if(e3 !=null)
							{
								System.out.println("Employee ID: "+e3.getEmpId());
								System.out.println("Employee Name: "+e3.getName());
								System.out.println("Employee Salary: "+e3.getSalary());
							}
							else
							{
								System.out.println("Employee Does Not Exist");
							}
							System.out.println("#####################");
							break;	
						case 5:
							
							System.out.println("#####################");
							System.out.println("Go Back");
							System.out.println("#####################");
							break;
							
						default:
							System.out.println("#####################");
							System.out.println("Invaild Choice");
							System.out.println("#####################");
							break;
					}
					System.out.println("********************");
					break;
				
				case 2:
				
					System.out.println("********************");
					System.out.println("Restaurant Management");
					System.out.println("What do you want to do?\n");
					System.out.println("--------------------------------------");
					System.out.println("1. Insert New Restaurant");
					System.out.println("2. Remove Existing Restaurant");
					System.out.println("3. Show All Restaurants");
					System.out.println("4. Search A Restaurant");
					System.out.println("5. Go Back");
					System.out.println("--------------------------------------\n");
					System.out.print("Enter your option: ");
					int input2 = sc.nextInt();
					
					switch(input2)
					{
						case 1:
							
							System.out.println("#####################");
							System.out.println("Insert New Restaurant");
							
							System.out.print("Enter Restaurant ID: ");
							String rid1 = sc.next();
							
							System.out.print("Enter Restaurant Name: ");
							String name1 = sc.next();
			
							Restaurant r1 = new Restaurant();
							r1.setRid(rid1);
							r1.setName(name1);
				
							b.insertRestaurant(r1);
							
							System.out.println("#####################");
							break;
							
						case 2:
						
							System.out.println("#####################");
							System.out.println("Remove Existing Restaurant");
							
							System.out.print("Enter Restaurant ID: ");
							String rid2 = sc.next();
							
							Restaurant r2 = b.getRestaurant(rid2);
							b.removeRestaurant(r2);
							
							System.out.println("#####################");
							break;	
							

						case 3:
							
							System.out.println("#####################");
							System.out.println("Show All Restaurants");
							
							b.showAllRestaurants();
							System.out.println("#####################");
							break;

						case 4:
								
                            System.out.println("#####################");
							System.out.println("Search A Restaurant");
							
							System.out.print("Enter Restaurant ID: ");
							String rid3 = sc.nextS();
							
							Restaurant r3 = b.getRestaurant(rid3);
							
							if(r3 !=null)
							{
								System.out.println("Restaurant ID: "+r3.getNid());
								System.out.println("Restaurant Name: "+r3.getName());
								r3.showAllRestaurants();
							}
							else
							{
								System.out.println("Restaurant Does Not Exist");
							}
							System.out.println("#####################");
							break;	
						case 5:
							
							System.out.println("#####################");
							System.out.println("Go Back");
							System.out.println("#####################");
							break;
							
						default:
							System.out.println("#####################");
							System.out.println("Invaild Choice");
							System.out.println("#####################");
							break;
					}
					System.out.println("********************");
					break;
					
				case 3:
				
					System.out.println("********************");
					System.out.println("Restaurant FoodItem Management");
					
					System.out.println("What do you want to do?\n");
					System.out.println("--------------------------------------");
					System.out.println("1. Insert New FoodItem");
					System.out.println("2. Remove Existing FoodItem");
					System.out.println("3. Show All FoodItems");
					System.out.println("4. Search A FoodItem");
					System.out.println("5. Go Back");
					System.out.println("--------------------------------------\n");
					System.out.print("Enter your option: ");
					int input3 = sc.nextInt();
					
					switch(input3)
					{
						case 1:
						    System.out.println("#####################");
							System.out.println("Insert New Food Item");
							
							System.out.print("Enter Food ID: ");
							String fid1 = sc.next();
							
							System.out.print("Enter Food Name: ");
							String name1 = sc.next();
							
							System.out.print("Enter Food Price: ");
							double price = sc.nextDouble();
							
							FoodItem f1 = new FoodItem();
							f1.setFid(fid1);
							f1.setName(name1);
							f1.setPrice(price);
							
							b.insertFoodItem(f1);
							
							System.out.println("#####################");
							break;
							
						case 2:
						
							System.out.println("#####################");
							System.out.println("Remove Existing Food Item");
							
							System.out.print("Enter Food ID: ");
							String fid2 = sc.next();
							System.out.print("Enter Food Name: ");
							String name2 = sc.next();
							
							b.getFoodItem(fid2).removeFoodItem(b.getFoodItem(fid2).getFoodItem(name2));
							
							System.out.println("#####################");
							break;
							
						case 3:
						
						   	System.out.println("#####################");
							System.out.println("Show All Food Items");
							
							b.showAllFoodItems();
							
							System.out.println("#####################");
							break;
							
							
						case 4:
						
						    System.out.println("#####################");
							System.out.println("Search A Food Item");
							
							System.out.print("Enter Food ID: ");
							String fid3 = sc.next();
							System.out.print("Enter Food Name: ");
							String name3 = sc.next();
							
							FoodItem fi = b.getFoodItem(fid3).getFoodItem(name3);
							
							if(fi != null)
							{
								fi.showInfo();
							}
							
							System.out.println("#####################");
							break;
						
						case 5:
						
							System.out.println("#####################");
							System.out.println("Going Back ....");
							System.out.println("#####################");
							break;
							
						default:

							System.out.println("#####################");
							System.out.println("Invalid Option");
							System.out.println("#####################");
							break;
						
					}
					
					System.out.println("********************");
					break;
								
				case 4:
				
					System.out.println("********************");
					System.out.println("FoodItem Quantity Add-Sell");
					
					
					System.out.println("What do you want to do?\n");
					System.out.println("--------------------------------------");
					System.out.println("1. Add FoodItem");
					System.out.println("2. Sell FoodItem");
					System.out.println("3. Show Add-Sell History");
					System.out.println("4. Go Back");
					System.out.println("--------------------------------------\n");
					
					System.out.print("Enter your option: ");
					int input4 = sc.nextInt();
					
					switch(input4)
					{
						case 1:
						
							System.out.println("#####################");
							System.out.println("Add FoodItem\n");
							
							System.out.print("Enter Food ID: ");
							String fid1 = sc.next();
							System.out.print("Enter Food Name: ");
							String name1 = sc.next();
							System.out.print("Enter Quantity: ");
							int quantity1 = sc.nextInt();
							
							if(amount1>0)
							{
								b.getFid(fid1).getName(name1).addQuantity(amount1);
								
								frwd.writeInFile("Name: "+ name1+" & Quantity: "+ amount1);
							}
							
							System.out.println("#####################");
							break;
							
						case 2:
						
							System.out.println("#####################");
							System.out.println("Sell FoodItem");
							
							System.out.print("Enter Food ID: ");
							String fid2 = sc.next();
							System.out.print("Enter Food Name: ");
							String name2 = sc.next();
							System.out.print("Enter Quantity: ");
							int quantity2 = sc.nextInt();
							
							if(amout2>0 && amount2 <= b.getFid(fid2).getName(name2).getPrice())
							{
								b.getFid(fid2).getName(name2).sellQuantity(amount2);
								
								frwd.writeInFile("Name	: "+ name2+" & Quantity: "+ 2);
							}
							
							System.out.println("#####################");
							break;
							
						case 3:
						
							System.out.println("#####################");
							System.out.println("Show Add-Sell History");
							frwd.readFromFile();
							
							System.out.println("#####################");
							break;
							
						case 4:
						
							System.out.println("#####################");
							System.out.println("Going Back..");
							System.out.println("#####################");
							break;
							
						default:
						
							System.out.println("#####################");
							System.out.println("Invalid Option");
							System.out.println("#####################");
							break;
					}
					
					System.out.println("********************");
					break;
								
				case 5:
				
					System.out.println("********************");
					System.out.println("Exit");
					choice = false;
					System.out.println("********************");
					break;
					
				default:
				
					System.out.println("********************");
					System.out.println("Invalid Option");
					System.out.println("********************");
					break;
			}
			
		}
		
		
	}
}
